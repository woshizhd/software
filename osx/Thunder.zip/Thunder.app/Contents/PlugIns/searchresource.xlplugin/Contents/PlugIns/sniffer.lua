require("whitelist")
local http = require("socket.http")
local ltn12 = require("ltn12")
local json = require("cjson")
local iconv = require("iconv")
local urlcode = require("socket.url")
local mime = require("mime")
local TerminateState = {NormalTerminateState=0, UserStopTerminateState=1 ,ErrorTerminateState=2,WhitelistTerminateState=3,SensitiveResourceTerminateState=4}
local SnifferState ={IDLE=0,Finished=1,Begin=2,Running=3,NoResource=4,NoCopyright=5}
local SnifferType = {NormalPage=0,BaiduPage=1}
http.TIMEOUT = 5 
-- lock_sniffer = false
resource_count = 0
--全局变量
local sniffer_server = 'http://interface.m.sjzhushou.com/sniffer/get'
local search_words_suffixes = {'迅雷下载','thunder','torrent','bt','百度云','QQ旋风'}
local extensions = {"mp4","swf","avi","rmvb","3gp","flv","wmv","mkv","mpg","torrent","txt","rtf","doc","docx","ppt","pptx","xls","xlsx","pdf","rar","zip","7z","mp3","wav","ram","wma","amr","aac","apk","ipa","ipsw","dmg","exe"}

--内部函数
function _log(...)
	if( DEBUG == true) then
		if(file_log == nil) then
			file_log = io.open("/tmp/sniffer.log",'w')
		end
		print(...)

		local linestr=tostring(os.date()) .. " -- "
		for i=1,select('#',...) do
			linestr = linestr .. tostring(select(i,...))
		end
		file_log:write(linestr .. "\n")
	end
end
function _split_str(input_str,sep)
	-- it's just for single character delimiters.
	if sep == nil then sep = "%s" end
	local t = {}
	for str in string.gmatch(input_str,"([^"..sep.."]+)") do
		table.insert(t,str)
	end
	return t
end
function _in_array(e,t)
	for _,v in ipairs(t) do
		if v == e then
		 return true 
		end
	end
	return false
end

function _str_starts_with(str,substr)
	if nil == str or nil == substr then return nil end
	if string.find(str,substr) ~= 1 then return false else return true end
end

function _str_ends_with( str,substr )
if nil == str or nil == substr then return nil end
local _substr = string.reverse(substr)
local _str = string.reverse(str)
if string.find(_str,_substr) ~= 1 then return false else return true end
end

function _file_extension(file)
	return file:match(".+%.(%w+)$")
end
function _print_array( array )
	for _,v in ipairs(array) do print(v) end
end

function _is_baidu_search_url(input_url)
	if(input_url ~= nil and string.match(input_url,"^%s*https?://www%.baidu%.com/s%?")) then
		return true
	else
		return false
	end
end

--嗅探相关函数
-- 上报结果
function _report_result(keyword,url,ref_url,file_name,file_size,cid,hash,token)
	-- 针对磁力链资源尝试解析出文件名
	url = urlcode.unescape(url)  -- 链接可能会被url编码过。所以统一url解码
	if( _str_starts_with(url,"^magnet")) then 
		local filename = string.match(url,"[;&]dn=([^;&]+)")
		file_name =urlcode.unescape(filename or "")
	elseif(_str_starts_with(url,"ed2k://")) then
	-- 尝试解析文件大小
		local componets = _split_str(url,'%|')
		if(nil ~= componets and #componets >=5) then
			if(string.match(componets[4],"%d+")) then file_size = componets[4] end
		end
	elseif(_str_starts_with(url,"thunder://")) then
	-- 检查thunder链接的有效性
		local b64code = string.match(url,"thunder://(.+)$") or ""	
		local rawurl = mime.unb64(b64code) or ""
		if(nil == string.match(rawurl,"^AA.+ZZ$")) then 
			_log("***** Invalid thunder url ***** \n" .. tostring(url) .. "\n***** Droped *******")
			return false 
		end

	end

	_log("_report_result:\n==============\n" .. "keyword:" .. tostring(keyword) 
		.. "\nresult: url:" .. tostring(url) 
		.. "\nref_url:" .. tostring(ref_url) 
		.. "\nfile_name:" .. tostring(file_name) 
		.. "\nfile_size:" .. tostring(file_size)
		.. "\ncid:" .. tostring(cid)
		.. "\nhash:" .. tostring(hash)
		.. "\ntoken:" .. tostring(token)
		.."\n==============\n"
		)
	post_search_result(keyword or "",url or "",ref_url or "",file_name or "",tonumber(file_size or "0"),cid or "",hash or "",token)
	resource_count = resource_count + 1
end

-- 从百度链接中解析出原始资源链接
function baidu_link_2_original_url(baidu_uri)
	--确保是一个有效的百度跳转链接,否则返回nil
	_log("** baidu_link => " .. tostring(baidu_uri))
	if nil == baidu_uri or string.find(baidu_uri,[[www%.baidu%.com/link%?]]) == nil then return nil end 
	local r,c,h = http.request(baidu_uri)
	if	r == nil then  
		print("<ERROR>: parser baidu link failed ! code:" .. tostring(c) .. "content:" .. tostring(c) .. "header:".. tostring(h))
		return nil
	end

	local url = h.location or string.match(r,[[window.location.replace%(%"(.-)%"%)]])
	_log("**parsed original_url => " .. tostring(url))
	return url
end

-- 从嗅探服务器上查找资源
function query_resource_from_server(original_url,keyword)
	_log("query_resource_from_server:" .. tostring(original_url) .. "\nkeyword:" .. tostring(keyword))
	if nil == original_url then return nil end 
	local server_url = sniffer_server
	--Mac迅雷 productId == 62
	local cookie_str = "productId=" .. "62" .."; channelId=" .. "tongbutui".."; version=" .. "5.9.4.3".."; versionCode=" .. "10270"
	local reqest_data = {
							['title'] = keyword or "",
							['reqList'] = {
											{
												['type'] = "refurl",
												['list'] = {
															original_url,
															}
											}
										}
	}
	 -- print (json.encode(reqest_data))

	 local reqbody = json.encode(reqest_data) or " "
	 local respbody = {}

	 local result,code,headers,status = http.request {
		 method = "POST",
		 url = server_url,
		 source = ltn12.source.string(reqbody),
		 headers = {
			 ['Cookie'] = cookie_str,
			 ['Connection'] = 'close',
			 ['Content-Type'] = "application/x-www-form-urlencoded",
			 ['Content-Length'] = tostring(#reqbody)
		 },
		 sink = ltn12.sink.table(respbody)

	}
	_log(table.concat(respbody))
	local sniffing_result = nil
	if (#respbody > 0) then
		sniffing_result = json.decode(table.concat(respbody))
		respbody = nil
	end
	return sniffing_result
end

-- 从页面中解析出资源的地址
function get_resouce(content,encode)
	if nil== content then return nil end
	local patterns ={"(magnet:%?xt=urn:btih:[^\"<\'$]+)", --magnet
					"(ed2k://|file|[^<]-|%d-|%w-|/?)", --ed2k
					"(thunder://[A-Za-z0-9+/]+=?=?)", --thunder
					"(ftp://[^\"\'%<%>%(%)%?]-%.%w%w%w?%w?%w?%w?%w?)[%s<>\"\'%(%)%^]",--ftp
					"(https?://[^\"\'%<%>%(%)%?]-%.%w%w%w?%w?%w?%w?%w?)[%s<>\"\'%(%)%^]",--http

				}
	local tocharset = "utf8"
	local fromcharset = encode or "utf8"
	local res_urls_uniq = {}

	--查找下载资源
	for _,v in ipairs(patterns) do
		for url in string.gmatch(content,v) do
			-- print ("matched" .. tostring(url))
			--筛选ftp/http链接
			if(_str_starts_with(string.lower(url),"ftp://") or _str_starts_with(string.lower(url),"http")) then
				local ext = _file_extension(string.lower(url))
				--ftp/http链接后缀判断
				if(_in_array(ext,extensions)) then
					res_urls_uniq[url] = true
				end
			else
				--magnet,ed2k,thunder，无需筛选
				res_urls_uniq[url] = true	
			end


		end
	end

	local urls = {}
	for k,_ in pairs(res_urls_uniq) do  
		--utf8字符转换
		_log("matched URL:".. k)
		if(fromcharset ~= 'utf8') then
			-- print("charset convert--->")
			local cd = iconv.new(tocharset,fromcharset)
			local url,err = cd:iconv(k)
			if err == iconv.ERROR_INCOMPLETE then
				print("ERROR: Incomplete input.")
				url = k
			elseif err == iconv.ERROR_INVALID then
				print("ERROR: Invalid input.")
				url = k
			elseif err == iconv.ERROR_NO_MEMORY then
				print("ERROR: Failed to allocate memory.")
				url = k
			elseif err == iconv.ERROR_UNKNOWN then
				print("ERROR: There was an unknown error.")
				url = k
			end
			table.insert(urls,url)
		else
			table.insert(urls,k)
		end
		_log("==>formated URL:" .. tostring(urls[#urls]))
	end
	return urls
end

-- 嗅探原始页面中的资源
function query_resource_from_original_page(original_url,keyword)
	_log("query_resource_from_original_page:" .. tostring(original_url) .. "\nkeyword:" .. tostring(keyword))

	local res, code, headers, status = http.request(original_url)
	local urls = {}
	if( nil ~= res) then
		--识别编码格式
		local encode = nil
		if(string.find(string.lower(res),"<head.-charset[%s]*=[\'\"%s]*gb[k2].*head>")) then
			_log("***convert charset from gb2312 to utf8")
			encode = "gb2312"
		end
		urls = get_resouce(res,encode)
	else
		_log("<WARN>: query_resource_from_original_page failed:" .. tostring(original_url) .." res:".. tostring(res) .." code:" .. tostring(code))
	end
	 -- print(res)
	 return urls
end

-- 获取用户输入的关键词
function get_keyword_from_url(ref_url)
 	local keyword=nil
 	local search_words = string.match(ref_url,"[%&%?]wd=([^&]+)%&?")
 	if(nil ~= search_words) then
		_log("**got keyword:".. search_words)
 		local words = _split_str(urlcode.unescape(search_words),"%s")
 		if  #words >= 2 and _in_array(words[#words],search_words_suffixes) then
 			--找到了关键字
 			keyword = words[1]
 		else
 			keyword = urlcode.unescape(search_words)
 		end
 	end
 	return keyword
end

-- 嗅探入口
function sniffing(origin_url,keyword,token)
--keyword 为nil表示嗅探普通页面，否则嗅探百度搜索页
	
	local ret=0
	local resources = {}
	if origin_url == nil then 
		print("<ERROR>:sniffer url can't be nil")
		return 2
	end

	local exist_record_on_server = false
    --第一步：针对百度搜索页的链接，从服务器嗅探
	if keyword ~= nil then
			local res = query_resource_from_server(origin_url,keyword)
			if(nil ~= res) then
				local refurlinfos = res['refurlinfo']
				local ret = res['ret']
				if(tostring(ret) ~= '0') then -- 资源被举报
					_log("<WARN>: server return:" .. tostring(ret))
					-- 黄色 反动 版权关键字返回1
					if (tostring(ret) == '1') then return 1 end
				else
					for _,refurlinfo in ipairs(refurlinfos) do 
						local fileinfo = refurlinfo['fileinfo']
						local ref_url = refurlinfo['refurl']
						local inblacklist = refurlinfo['inblacklist']
						local head = refurlinfo['head']
						if(nil ~= fileinfo and #fileinfo >= 1 )then
							for _,info in ipairs(fileinfo) do
								local file_name = info['filename']
								local url = info['url']
								local file_size = info['filesize']
								local cid = info['cid']
								local hash = info['hash']
								if(#url > 10) then
									exist_record_on_server = true 
								--	_report_result(keyword,url,ref_url,file_name,file_size,cid,hash,token)
								table.insert(resources,{keyword,url,ref_url,file_name,file_size,cid,hash,token})
								end
							end
						end
					end
				end
			end
	end
	--第二步：当服务器上没有找到资源时，从原始资源页面嗅探。
	if(exist_record_on_server == false) then
		local urls = query_resource_from_original_page(origin_url,keyword)
		for _,v in ipairs(urls) do 
				--_report_result(keyword,v,origin_url,nil,nil,nil,nil,token) 
				table.insert(resources,{keyword,v,origin_url,nil,nil,nil,nil,token})
		end
	end
	--第三步：针对百度链接进行过滤。目的是为了在界面上只展示一条理想的结果
	if(keyword ~= nil) then -- 百度搜索页上报一条结果
		local matched = false
		for _,v in ipairs(resources) do
			local file_name = v[4]
			if(nil ~=file_name and string.find(file_name,keyword)) then
				_report_result(v[1],v[2],v[3],v[4],v[5],v[6],v[7],v[8])
				matched = true
				break
			end
		end
		-- 当没有找到最佳的资源时上报第一条记录
		if (matched == false and #resources > 0) then 
			local v = resources[1]	
			_report_result(v[1],v[2],v[3],v[4],v[5],v[6],v[7],v[8])
		end
	else -- 普通页上报所有结果
		for _,v in ipairs(resources) do
				_report_result(v[1],v[2],v[3],v[4],v[5],v[6],v[7],v[8])
		end
	end
	return 0 
end

-- 开始百度搜索页的嗅探 
function handle_baidu_page(content, ref_url) 
	if nil == ref_url then return nil end
	_log("handle_baidu_page:"..ref_url)
	resource_count = 0
	local exitStatus = TerminateState.NormalTerminateState
	 --获取地址栏的搜索关键字
	local keyword = get_keyword_from_url(ref_url)
 	_log("search keyword:" ..  tostring(keyword))
	show_popover(SnifferState.Running,keyword or "")

	-- 百度页面的嗅探
	local token = os.time()
	begin_sniffing(SnifferType.BaiduPage,token,ref_url)

 	if nil == content then
 	 _log("<WRAN>:baidu page content can't be nil") 
	else
		--获取页面的原始资源链接
		local b_link_pattern = "href=\"(http://www%.baidu%.com/link%?url=.-)\".-</h3>"
		local top_10_urls = {}
		local origin_urls = {}
		for url in string.gmatch(content,b_link_pattern) do top_10_urls[url] = true end
		local url_index = 1
		for k,_ in pairs(top_10_urls) do 
			local current_token = coroutine.yield(url_index,k,keyword)
			_log("coroutine.yield value:" .. tostring(current_token ))
			-- 用户停止了嗅探
			if(current_token ~= token) then 
				exitStatus = TerminateState.UserStopTerminateState
				_log("** User stop sniffing...")
				break
			 end
			local origin_url = baidu_link_2_original_url(k)
			-- 检查白名单
			if(origin_url ~=nil) then
				if(is_in_white_list(origin_url)) then
					_log("** is_in_white_list：" .. tostring(origin_url))
				else
					local ret = sniffing(origin_url,keyword,token)
					-- 检查敏感关键字
					if(ret == 1) then
							exitStatus = TerminateState.SensitiveResourceTerminateState
							break;
					end
				end
			end
			url_index = 1 + url_index
		end
 	end

	end_sniffing(SnifferType.BaiduPage,token,exitStatus)
	_log("***baidu_page resource count:".. tostring(resource_count) .. " Elapsed time:" .. tostring(os.time() - token).. "s")

end

-- 开始普通页面的嗅探
function handle_normal_page(content,ref_url)
	if nil == ref_url then return nil end
	_log("handle_normal_page:"..ref_url)
	resource_count = 0
	local token = os.time()
	-- 非百度搜索页面的嗅探
	begin_sniffing(SnifferType.NormalPage,token,ref_url)

	-- 检查白名单
	if(is_in_white_list(ref_url)) then
		_log("** is_in_white_list：" .. tostring(ref_url))
		end_sniffing(SnifferType.NormalPage,token,TerminateState.WhitelistTerminateState)
		return 
	end


 	if (nil == content)then
 	 _log("<WRAN>:page content is nil") 
 	 sniffing(ref_url,nil,token)
 	else
 		local urls = get_resouce(content,'utf8')
 		if nil ~= urls and select('#',urls) > 0 then
			for _,v in ipairs(urls) do _report_result("",v,ref_url,nil,nil,nil,nil,token) end
		end
 	end

	end_sniffing(SnifferType.NormalPage,token,TerminateState.NormalTerminateState)

	_log("normal page resource count:".. tostring(resource_count).. " Elapsed time:".. tostring(os.time() - token) .. "s")

end


-- 接口：页面加载完成,同步
function did_finish_load_frame(frame,ref_url)
	--产品不想用此接口，弃用！
	--[[
	local page_content = get_frame_content(frame)
	_log("did_finish_load_frame,content size:" ..tostring(#tostring(page_content)) .. "URL:" .. tostring(ref_url))
	local content = page_content
	-- 如果content 为空则启动本地http请求。
	if((nil ~= content) and (nil ~= ref_url))then
		if(_is_baidu_search_url(ref_url) == false) then
			handle_normal_page(content,ref_url)		
		end
	end
	--]]
end
-- 接口：用户在百度页输入关键字触发的嗅探
function sniffing_keyword(keyword)
	if(keyword == nil or string.len(keyword) == 0) then return false end
	local ref_url = string.format("https://www.baidu.com/s?ie=utf-8&tn=49029047_dg&wd=%s",urlcode.escape(keyword)) 
	_log("sniffing_keyword:".. tostring(ref_url))
	local content = http.request(ref_url)
	handle_baidu_page(content,ref_url)
end
-- 接口：判断是否需要载入连接 ,同步
function decide_policy_for_navigation_url(request_url)
	_log("decide_policy_for_navigation_url:".. tostring(request_url))

	local ignor_list ={"%s*about:blank%s*","p%.%w%w%w%w%.com","3dwwwgame%.com","4%.%w%w%w%w%.com","c%.%w%w%w%w%.com","vda%.%w%w%w%w%.net","tanshengpazi","www%.sbdsh%.cn","news%.%d%d%d%d%d%d%.com","fttest%.365sky%.com","ruilongv%.com","p%.qiyou%.com","%.quanxinzaocan%.space","mp%.weixin%.qq%.com","www%.u17%.com","www%.nka111%.com","www%.yansaohan%.win","www%.mohipaper%.cn","www%.%w%w%w%w%.pw","p%.%w%w%w%w%.cn","t%.%d%d%d%d%d%d%.com","www%.jkl111%.com"}
	local _is_valid = true
	for _,domain in ipairs(ignor_list) do
		if string.match(tostring(request_url),domain) then
			_is_valid = false
			_log("ignore url:" .. request_url)
			break
		end
	end
	return _is_valid
end

-- 接口：webview的frame收到新的request,同步
function did_start_provisional_load_for_frame(ref_url,frame)
	
	_log("did start provisional load for ".. "url:" .. tostring(ref_url).."frame:"..type(frame))
	-- print(tostring(get_frame_content(frame)))
--	local content = get_frame_content(frame)
	if(_is_baidu_search_url(ref_url)) then
		local content = http.request(ref_url)
		handle_baidu_page(content,ref_url)
	else
		local content = nil --产品觉得需要重新请求一次
		handle_normal_page(content,ref_url)
	end
end

-- 调试环境
if(nil == post_search_result) then
	local token  = os.time()
	post_search_result= function ( keyword,url,ref_url,file_name,file_size,cid ,hash )
		-- body
		print("post_search_result==> keyword: " .. keyword 
			.." url:" ..url)
	end
	begin_sniffing= function(sType,timestamp ,ref_url)
		token = timestamp
		print("begin_sniffing:" .. tostring(timestamp))
	end
	end_sniffing = function(sType,token,state )
		if (state == 4) then print("<WARN>:sensitive resource !!!")end
		print("end_sniffing:" .. tostring(state))
	end
	show_popover = function (state,msg)
		print("show_popover:" .. tostring(state) .. " message:" .. tostring(msg))
	end
	get_frame_content=function ( url )
		return http.request(url)
	end

	DEBUG = true

		local url = arg[1]
		if(nil ~= url) then
				local p=nil
				if(string.match(url,'^https?://')) then
					p = coroutine.create(did_start_provisional_load_for_frame)
					local ret,idx,url,keyword = coroutine.resume(p,url,url)
				else
					p = coroutine.create(sniffing_keyword)
					local ret,idx,url,keyword = coroutine.resume(p,url) 
				end
				local ret = true
				while coroutine.status(p) ~= "dead"
				do
					local start = os.time()
					print("\n\n++" .. tostring(idx) , tostring(url), tostring(keyword))
					ret,idx,url,keyword = coroutine.resume(p,token)
					print("==>Sniffing Elapsed Time:".. tostring(os.time() - start).. "s")
					if ret == false then break end
				end
		end
end

