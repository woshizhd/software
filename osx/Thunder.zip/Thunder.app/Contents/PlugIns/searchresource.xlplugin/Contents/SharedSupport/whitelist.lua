local white_list_url = "http://plugin.xl7.xunlei.com/7.9/normal/NoSniffingUrlList.ini"

--硬编码的白名单，以备网络异常时使用，下载的白名单文件中的url也会加进来
local white_list_local = {
    --自己的域名不需要嗅探
    "xunlei%.com",
    --政府网站
    "gov%.cn",
    --银行，证券类
    "icbc%.com%.cn",
    "ccb%.com",
    "boc%.cn",
    "bankcomm%.com",
    "abchina%.com",
    "cmbchina%.com",
    "psbc%.com",
    "cebbank%.com",
    "cmbc%.com%.cn",
    "pingan%.com",
    "spdb%.com%.cn",
    "ecitic%.com",
    "cib%.com%.cn",
    "hxb%.com%.cn",
    "cgbchina%.com%.cn",
    "nbcb%.com%.cn",
    "gzcb%.com%.cn",
    "njcb%.com%.cn",
    "cmbc%.com%.cn",
    "webank%.com",
    --电商
    "jd%.com",
    "taobao%.com",
    "tmall%.com",
    "yhd%.com",
    "suning%.com",
    "amazon%.cn",
    "jumei%.com",
    "vip%.com",
    "dangdang%.com",
    "zhe800%.com",
    "mogujie%.com",
    "miyabaobei%.com",
    "jiuxian%.com",
    "dianping%.com",
    "yiwugou%.com",
    "gome%.com%.cn",
    "masamaso%.com",
    "111%.com%.cn",
    "nuomi%.com",
    "yohobuy%.com",
    "metao%.com",
    "meituan%.com",
    --支付
    "alipay%.com",
    "baifubao%.com",
    "pingxx%.com",
    "qtplay%.com",
    "95516%.com",
    "cpay%.qq%.com",
    "midas%.qq%.com",
    "lianlianpay%.com",
    "payment%.ipaynow%.cn",
    "iapppay%.com",
    "heepay%.com",
    --关键词过滤
    "login",
    "register",
    "password",
    "pay",
}

function is_in_white_list(url)
	-- body
	if url == nil then return false end
	for _, keyWord in ipairs(white_list_local) do
        if url:match(keyWord) ~= nil then
            return true
        end
    end
    return false
end
